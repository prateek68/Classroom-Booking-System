import java.io.Serializable;
import java.util.ArrayList;
import com.csvreader.*;
public class Management implements Serializable{
	private ArrayList<Room> rooms;
	private ArrayList<Courses> courses;
	private ArrayList<Person> users;
	Management(){
		rooms=new ArrayList<Room>();
		courses=new ArrayList<Courses>();
		users=new ArrayList<Person>();
	}
	public ArrayList<Room> getRooms() {
		return rooms;
	}
	public void setRooms(ArrayList<Room> rooms) {
		this.rooms = rooms;
	}
	public ArrayList<Courses> getCourses() {
		return courses;
	}
	public void setCourses(ArrayList<Courses> courses) {
		this.courses = courses;
	}
	public ArrayList<Person> getUsers() {
		return users;
	}
	public void setUsers(ArrayList<Person> users) {
		this.users = users;
	}
	public static void deserialize() {
		
	}
	public static void serialize() {
		
	}
	public void signup() {
		
	}
	public void signin() {
		
	}
	public void adduser() {
		
	}
	public void addroom() {
		
	}
	public void addcourse() {
		
	}
	public void deluser() {
		
	}
	public void delroom() {
		
	}
	public void delcourse() {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
