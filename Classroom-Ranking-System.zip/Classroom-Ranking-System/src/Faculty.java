import java.util.ArrayList;

public class Faculty extends Person{
	private ArrayList<Room> rooms;
	public ArrayList<Room> getRooms() {
		return rooms;
	}
	public void setRooms(ArrayList<Room> rooms) {
		this.rooms = rooms;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	@Override
	public void login() {
		// TODO Auto-generated method stub
		
	}
	public void book_room() {
		
	}
	public void cancel_booking() {
		
	}
	public void viewTimeTable(TimeTable timetable) {
		
	}

}
