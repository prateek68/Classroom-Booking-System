import java.util.ArrayList;

public class TimeTable {
	private ArrayList<Courses> courses;
	public ArrayList<Courses> getCourses() {
		return courses;
	}
	public void setCourses(ArrayList<Courses> courses) {
		this.courses = courses;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
