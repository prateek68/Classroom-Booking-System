import java.util.ArrayList;

public class Student extends Person{
	private TimeTable personalizedTimetable;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public TimeTable getPersonalizedTimetable() {
		return personalizedTimetable;
	}
	public void setPersonalizedTimetable(TimeTable personalizedTimetable) {
		this.personalizedTimetable = personalizedTimetable;
	}

	@Override
	public void login() {
		// TODO Auto-generated method stub
		
	}
	public void makerequest() {
		
	}
	public void viewTimeTabe(TimeTable timetable) {
		
	}
	public void viewpersonalizedTimeTabe() {
		
	}
	public void addcourse() {
		
	}
	public void leavecourse() {
		
	}
	public void view_pending_requests() {
		
	}
	public ArrayList<Courses> searchcourses(ArrayList<String> keywords){
		return null;
		
	}
}
