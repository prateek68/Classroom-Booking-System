
public class Room {
	private String name;
	private int Capacity;
	Room(String number, int c){
		name=number;
		Capacity=c;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCapacity() {
		return Capacity;
	}
	public void setCapacity(int capacity) {
		Capacity = capacity;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
